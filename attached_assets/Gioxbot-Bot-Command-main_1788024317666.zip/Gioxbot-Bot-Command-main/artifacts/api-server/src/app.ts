import express, { type Express, type Request, type Response } from "express";
import cors from "cors";
import router from "./routes";

const app: Express = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Homepage
app.get("/", (_req: Request, res: Response) => {
  res.status(200).send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Gioxbot Bot Command API</title>
  <style>
    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      font-family: Arial, sans-serif;
      background: #0f172a;
      color: #fff;
    }

    .card {
      width: 100%;
      max-width: 650px;
      padding: 35px;
      text-align: center;
      background: #1e293b;
      border-radius: 20px;
      box-shadow: 0 20px 50px rgba(0,0,0,.35);
    }

    h1 {
      margin: 0 0 15px;
      font-size: 30px;
    }

    p {
      color: #cbd5e1;
      line-height: 1.6;
    }

    .status {
      display: inline-block;
      margin: 20px 0;
      padding: 10px 18px;
      border-radius: 999px;
      background: #166534;
      font-weight: bold;
    }

    .api {
      margin-top: 15px;
      padding: 15px;
      border-radius: 10px;
      background: #0f172a;
      text-align: left;
    }

    footer {
      margin-top: 25px;
      color: #94a3b8;
      font-size: 13px;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>🤖 Gioxbot Bot Command API</h1>

    <div class="status">
      ● API ONLINE
    </div>

    <p>
      Gioxbot Bot Command API is running successfully on Vercel.
    </p>

    <div class="api">
      <strong>API Status</strong><br />
      GET /api/health
    </div>

    <footer>
      Express.js • Vercel
    </footer>
  </div>
</body>
</html>
  `);
});

// Health check
app.get("/api/health", (_req: Request, res: Response) => {
  res.status(200).json({
    success: true,
    status: "online",
    service: "Gioxbot Bot Command API"
  });
});

// Existing API routes
app.use("/api", router);

export default app;
